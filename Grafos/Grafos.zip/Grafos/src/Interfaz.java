import javax.swing.*;

public class Interfaz {
    private JPanel panel1;
    private JCheckBox direccionadoCheckBox;
    private JCheckBox conPesoCheckBox;
    private JButton crearButton;
    private JButton quemarButton;
    private JTextField textField1;
    private JButton insertarButton;
    private JComboBox comboBox1;
    private JComboBox comboBox2;
    private JTextField textField2;
    private JButton insertarButton1;
    private JButton mostrarGrafoButton;
    private JComboBox comboBox3;
    private JButton DFSButton;
    private JButton BFSButton;
    private JButton dijkstraButton;
    private JTextArea textArea1;
}
