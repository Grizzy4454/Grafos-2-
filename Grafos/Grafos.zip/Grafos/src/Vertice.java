public class Vertice {
}
